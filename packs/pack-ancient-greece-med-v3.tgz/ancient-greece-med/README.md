# ancient-greece-med content pack (v1, 2026-10-22)
Files: content.json (entries grouped by section), sources.json (id, title, author_org, url, date_accessed, quality).
Entry schema: {id, text, sources[] (ids in sources.json), label ("evidence" | "inference" | qualified evidence), optional coords {lat, lon, source_format DMS}, uncertainty, sensitivity, debate}.
Coordinates: only where a source (UNESCO) gives them, converted from DMS. null means not sourced. UNESCO points are site centroids.
Labels: "evidence" means it is stated in the cited source. "inference" is marked inline. Some peer-reviewed items were read only at abstract or summary level, and their labels say so.
Validation: valid JSON; every entry has >=1 source id that resolves in sources.json.

## Gaps / uncertainty
Period dates are conventions (Met and Pyrgos differ on Archaic start). Myth entries cite UNESCO summaries, not primary texts (Homer, Hesiod, Pausanias are next). Mycenae and Minoan have no single coordinate (they are serial sites). The pack is Greece-only so far; wider Mediterranean (Troy, Paestum, Syracuse, Knossos individually, Phoenician/Egyptian) still to do.

## v2 expansion (2026-10-22)
Counts: periods 6, myths_places 22, sites 28 (21 new, 14 of them outside Greece: Italy, Malta, Tunisia, Libya, Lebanon, Cyprus, Albania, Türkiye). 36 sources.
Primary texts used, all public domain:
- Homer, Iliad and Odyssey (Butler translations, Project Gutenberg).
- Hesiod and the Homeric Hymns (Evelyn-White 1914, Project Gutenberg). Passages were checked by searching the downloaded text.
- Pausanias Book 2.1-14 (Jones 1918, via theoi.com), read in full.
Remaining gaps:
- Coordinates: 11 sites are null because UNESCO didn't show DMS (serial sites).
- Pausanias: Books 1, 5 and 10 (Athens, Olympia, Delphi) weren't fetched. The theoi pages blocked curl; WebFetch works.
- Primary-text entries give work and section, not line numbers, except Pausanias.
- Odyssey place identifications are mythical and flagged uncertain.
- Wider Mediterranean still missing: Egypt (Alexandria), Iberia, Marseille (Massalia).

## v3 (2026-10-22)
Line/section refs: Hesiod and Homeric Hymn line ranges from Evelyn-White section markers; Iliad Aulis 2.280-319 (Perseus card), Mycenae card 2.560-599 (inference by adjacency); Odyssey book-level only. Pausanias Books 1 (1.17-29), 5 (5.1-15), 10 (10.1-16) read from theoi; 19 new section-cited entries. Egypt (Memphis, Thebes, Abu Mena, Nubia, Alexandria), Iberia (Tarraco, Mérida, Lugo, Emporion), Massalia, Naples added. New sections people/timeline/further_reading.
Gaps: Alexandria, Emporion, Massalia are search-summary level (no page read, no coords); UNESCO serial sites lack single coordinates; Odyssey line numbers; Pausanias 1.1-16, 1.30-44, 5.16-27, 10.17-38 not read.
